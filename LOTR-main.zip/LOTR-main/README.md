# LOTR
Створено для участі в Logika Hackathon 2025
